package betafunction;

import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class costest {

	@Test
	public void test() {
		assertEquals(0.020066577841241662,beta.cos(0.2,4.8));
	}

}
