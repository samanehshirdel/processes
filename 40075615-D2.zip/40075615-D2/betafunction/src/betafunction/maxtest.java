package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class maxtest {

	@Test
	public void test() {
		assertEquals(7.8888,beta.max(7.8,7.8888));
		
	}

}
