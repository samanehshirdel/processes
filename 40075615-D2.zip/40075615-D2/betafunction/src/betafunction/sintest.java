package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class sintest {

	@Test
	public void test() {
		assertEquals(-0.2165728197473471,beta.sin(1.74,2.34));
	}

}
