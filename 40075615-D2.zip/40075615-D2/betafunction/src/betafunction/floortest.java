package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class floortest {

	@Test
	public void test() {
		assertEquals(1.0,beta.floor(1.37));
	}

}
