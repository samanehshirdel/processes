package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class Gammatest {

	@Test
	public void test() {
		
		assertEquals(4.590843711998803,beta.Gamma(0.2));
	
	}

}
