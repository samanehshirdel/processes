package betafunction;

import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
public class scaletest {

	@Test
	public void test() {
		assertEquals(62.4,beta.scale(7.8,3));
	}

}
