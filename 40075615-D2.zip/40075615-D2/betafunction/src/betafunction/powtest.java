package betafunction;

import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class powtest {

	@Test
	public void test() {
		  assertEquals(0.2349237886176038, beta.pow(0.2,0.9));
	}

}
