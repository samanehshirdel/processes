package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class abstest {

	@Test
	public void test() {
		assertEquals(5.7,beta.abs(-5.7));
	}

}
