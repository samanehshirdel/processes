package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class exptest {

	@Test
	public void test() {
		assertEquals(36.59823444367799,beta.exp(3.6));
	}

}
