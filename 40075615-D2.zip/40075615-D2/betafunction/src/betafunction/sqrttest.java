package betafunction;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class sqrttest {

	@Test
	public void test() {
		assertEquals(1.3038404810405297,beta.sqrt(1.7));
	}

}
